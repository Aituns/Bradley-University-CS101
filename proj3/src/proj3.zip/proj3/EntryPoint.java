/*
* @Austin Bennett
* <p> EntryPoint
* <p> Project 3
* <p> This code holds the main function which starts up the game controller class
*/
public class EntryPoint
{
	public static void main(String[] args)
	{
		//
		// start up
		//
		GameController gc = new GameController();
		gc.play();
	}

}
